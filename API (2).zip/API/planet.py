import requests
import time

def get_planet_degree(planet_name):
    # Using the NASA API to get planetary data
    url = f"https://api.le-systeme-solaire.net/rest/bodies/{planet_name}"
    response = requests.get(url)
    if response.status_code == 200:
        planet_data = response.json()
        return planet_data["discovered_by"]["degrees"]
    else:
        print(f"Failed to retrieve data for {planet_name}. Please try again later.")
        return None

def main():
    while True:
        planet_name = input("Enter the name of the planet you want to see (e.g., Earth, Mars): ")
        planet_name = planet_name.capitalize()  # Capitalize first letter
        degree = get_planet_degree(planet_name)
        
        if degree is not None:
            print(f"The current degree of {planet_name} is: {degree}°")
        
        # Wait for a few seconds before checking again
        time.sleep(5)

        # Ask the user if they want to continue
        continue_prompt = input("Do you want to see the degree of another planet? (yes/no): ")
        if continue_prompt.lower() != "yes":
            break

if __name__ == "__main__":
    main()

