import requests
from bs4 import BeautifulSoup

def get_planetary_position(year, month, day, planet_name):
    url = 'http://www.true-node.com/eph1/'
    payload = {
        'cyear': year,
        'cmonth': month,
        'cday': day,
        'geo': 'geocentric',
        'h': '0'
    }

    response = requests.post(url, data=payload)
    if response.status_code == 200:
        soup = BeautifulSoup(response.content, 'html.parser')
        # Find the table containing planetary positions
        table = soup.find('table', class_='detail')
        if table:
            rows = table.find_all('tr')
            for row in rows:
                cells = row.find_all('td')
                if cells and cells[0].text.strip().lower() == planet_name.lower():
                    degree = cells[2].text.strip()
                    print(f"The degree of {planet_name} on {year}-{month}-{day} is: {degree}°")
                    return
            print(f"No position found for {planet_name} on {year}-{month}-{day}.")
        else:
            print("No planetary positions found for the specified date.")
    else:
        print("Failed to retrieve data from the website.")

def main():
    year = input("Enter the year (YYYY): ")
    month = input("Enter the month (MM): ")
    day = input("Enter the day (DD): ")
    planet_name = input("Enter the name of the planet: ")

    get_planetary_position(year, month, day, planet_name)

if __name__ == "__main__":
    main()
